import styled from "styled-components";

export const Image = styled.img`
  max-width: 100%;
  border-radius: 1px;
`;
