import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";
import { Item } from "./components/Item";
import thumbnailUrl from "./thumbnail.jpg";

function App() {
  return (
    <Item
      title="Interstellar - A Documentary"
      subtitle="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
      imageUrl={thumbnailUrl}
    />
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
